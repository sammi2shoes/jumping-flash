# Single-leg prototype: fixed reference and held enable

Current MotorRecovery v0.11 targets StickC Plus2, MiniCAN GPIO32TX/GPIO33RX, RS05 CAN2.0 firmware0.5.0.14, motor1/host126,1Mbps. Build environment motor-recovery. It supersedes the per-arm relative reference in v0.9 and earlier. The current prototype has no locking mechanism. One leg is attached; the spring can extend the mechanism when torque is disabled. No jump, spinner, second leg or automatic homing is implemented.

## Startup and controls

1. Boot with motor disabled, connect the controller and wait for SET ZERO: B 2s. No reference is captured automatically.
2. With the leg mechanically supported against its ankle spring, manually position it at the known fully retracted pose. Center the controller stick and release R1. Release the Stick's side buttonB, then hold it for2seconds. Two encoder reads100ms apart must be stationary within0.002rad. This checks stillness, not whether the operator selected the correct pose. No driving into hard stops occurs.
3. Wait for ZERO CAPTURED and READY. Center the stick, then press/hold R1 to enable. Left-stick X right extends toward80deg; left retracts toward0deg. Extension decreases encoder position.
4. Keep R1 held: neutral ramps target velocity to zero and actively holds the resulting position. Release R1, press front buttonA, send serialx, or lose/stale Bluetooth input to request torque disable. R1 remains a held enable; the proposed toggle was cancelled. Disable can release stored spring energy; active hold is not a mechanical brake.

Current remains1A, speed1rad/s, host target-rate acceleration5rad/s^2, travel0..80deg and motor watchdog20000counts (nominal1s). Holding torque at1A has not been validated against this spring. The fixed0/80deg limits apply to every arm within the referenced session. After disarm the target is preloaded from the new measured position, not replayed, while the original zero remains unchanged. Center/release then fresh R1 press is still required after a stop/reconnection. There is no output for the spinner ESC.

## Reference trust and recovery

The manual reference is assigned once per Stick startup. Buttons cannot overwrite it after capture. Normal confirmed stops and Bluetooth disconnect/reconnect preserve the zero and continue position/settings monitoring while disabled. Before arming, position must remain in range and control mode, current limit, speed limit and watchdog must read back correctly. These settings are also checked periodically during active/disabled monitoring.

CAN read/target failures, an unconfirmed stop, faults, unexpected disabled feedback while active, changed/unreadable settings or a motor identification broadcast invalidate the reference. The numeric zero is retained for diagnostics, but motion is blocked. Reference cannot be recaptured within that session: restart, restore the known retracted pose and repeat the manual procedure. After uncertain stopping,1250ms without control transmissions allows the motor watchdog to expire before recovery. A confirmed ordinary stop instead continues disabled monitoring, since polling cannot re-enable an already confirmed disabled motor.

This is not a physical home sensor or a reset-proof reference. Zero is in RAM, not persisted through Stick power loss. A motor reset that preserves settings and returns a plausible in-range encoder value could escape these software checks. Any known motor power cycle/reset requires restarting and manually referencing, regardless of the display. An independent home/reference sensor and reset detection are needed to guarantee physical reference integrity across all resets. Calibration, motor-zero setting, fault clearing, parameter saves and automatic enable are never issued.

## Validation

v0.11 host simulation covers required manual reference, short/unsafe button holds rejected, held R1 and neutral position hold, both80deg endpoints, unchanged zero through mid-stroke disarm/rearm and Bluetooth reconnection, recapture blocked, CAN/settings uncertainty blocking enable without changing zero, readback tolerances and mailbox handling. Hardware validation of this version is pending. Prior v0.6 logs establish observed motion/R1-release disable; the user reported later v0.9 motion, controller-loss stop/reconnect and correct direction with the leg attached. Those reports do not validate this new fixed-reference implementation or holding torque under spring load. Historical version notes below describe earlier behavior and are not current operating instructions.

## v0.2: Bluetooth connection classification and diagnostics

The first hardware attempt reported paired Bluetooth but PAD LOST/STALE and no movement. That is correctly gated movement, not a reason to relax input freshness or increase current. The connection callback filtered isGamepad before retaining the handle. Bluepad32's official Controller example retains the handle in onConnected and checks its class when processing reports; class data may not be available until input arrives. v0.2 retains the connected handle, then still requires real gamepad reports and the existing200ms freshness limit before accepting controls. This fixes a plausible dropped-handle path; the actual user's cause remains pending updated device output.

A once-per-second PAD diagnostic prints physical link, gamepad class, freshness, report count/age, leftX, RB_R1 and phase. Display distinguishes NO LINK / WAIT TYPE / NO REPORTS / FRESH / STALE. The motor remains gated by the same freshness, neutral-input and release/press rules. Regression simulation covers late classification and connected-without-reports refusing to arm, plus prior motion/recovery/failsafe cases. ESP32+Bluepad32 build passes. Download releases/MotorRecovery-v0.2.zip; the unversioned MotorRecovery.zip is refreshed to match. Hardware verification is pending.

## v0.3: CAN transmit mailbox pacing

The v0.2 hardware log showed repeated configuration failures with confirmed STOP replies, plus PAD link=0 and no reports. With the software TX queue disabled, consecutive sends could encounter an occupied hardware mailbox. v0.3 waits up to20ms for the preceding transmission before sending another frame, services input/stop handling during that wait, and keeps single-shot transmission and the queue disabled. A blocked mailbox, driver error, failed TX, or mismatching parameter readback now prints a specific diagnostic. This addresses a plausible transport failure; on-device confirmation is pending.

Host simulation now models a busy mailbox between frames and verifies bounded failure when it stays busy. The ESP32 build passes. Bluetooth discovery is explicitly enabled; pairing keys are preserved. The current controller is an 8BitDo Ultimate2, whose exact variant and mode still need identification; no compatibility or pairing fix is claimed. Bluetooth freshness and motor arming gates are unchanged. Download releases/MotorRecovery-v0.3.zip.

## v0.4: Bluetooth first

Startup attempts STOP once, then displays CONNECT PAD and waits for fresh Bluetooth gamepad reports before any configuration writes or normal motor polling. Pair/reconnect the controller as usual; stored pairing keys remain intact. After input arrives, the disabled motor configuration is verified, then the existing centered-stick release/press RB/R1 gate applies. Reconnection after a loss also waits for fresh input. This does not force a controller into pairing mode or assert Ultimate2 compatibility. Simulation verifies no configuration traffic while waiting, followed by normal deliberate arming. Hardware confirmation remains pending.

## v0.5: bounded position-target readback tolerance

Hardware v0.4 reports confirmed fresh Ultimate2 gamepad input, ACTIVE state with joystick changes, shaft movement, and disabled confirmation on R1 release. One recovery failed exact position-target verification: wanted3D25CB84 (0.040477291rad), returned3D26334A (0.040576257rad), a difference0.000098966rad. The source of the difference is not established. Only index0x7016 now accepts finite readback within0.0002rad (0.0115deg); other settings retain exact comparisons. Simulation covers this measured-size discrepancy across startup/active operation, larger mismatch rejection, nonfinite rejection and existing failsafe paths. Speed remains0.10rad/s, current1A, travel+/-5deg; this is not continuous-rotation firmware. Hardware verification of v0.5 is pending.

## v0.6: smoother unloaded bench motion, +/-20 degrees

At the user's request, relative travel is now +/-20deg around each deliberate arming position (40deg total range). Current remains1A and maximum target rate0.10rad/s (5.73deg/s). A host-side rate ramp limits changes to0.50rad/s^2, including starts, neutral transitions and reversals. At a travel boundary the target is clamped and its rate reset. Release R1, stale input, faults and explicit stops bypass the ramp and request disable immediately. Arming resets the ramp; no prior rate is restored. Serial MOTION lines show measured/target displacement and target rate in degrees.

Full-stick travel from center to20deg takes about3.6seconds with the ramp; this is not continuous rotation or the calibrated0–80deg leg mode. Keep the mechanism disconnected. The current position mode (CSP,5) and watchdog setting are retained. Simulations exercise both20deg boundaries, gradual starts/reversals, existing stops/recovery and readback handling; hardware validation remains pending.

Reference reviewed: [JumpRopeStick](https://github.com/amcchord/JumpRopeStick/tree/2e916574c885e0a7f2b75004d01ce229965df853), especially main/sketch.cpp, controller_manager.cpp, motor_manager.cpp, web_server.cpp and robstride_protocol.h. Useful ideas include motor-role mapping, mode state machines, telemetry/dashboard separation and PP positioning. Its automatic fault clearing, mechanical zero setting and re-enabling are not adopted. No source was copied. RS05-specific [manual260713](https://github.com/RobStride/Product_Information/blob/384cc561e1ff079c22f68b19908526094430febd/Product%20Literature/CAN2.0/RS05/RS05User%20Manual260713.pdf), sections3.4.4 and4.1.14, confirms PP mode1 and speed0x7024/acceleration0x7025 (marked write-only). Switching to PP remains a separate validation task, including watchdog behavior in that mode.

## v0.6 hardware motion result

User-supplied [session log](bench-logs/motor-recovery-v0.6-motion.txt) starts at the v0.6 banner; earlier v0.4 idle lines from the same pasted upload are omitted. Startup STOP confirmed, Bluetooth connected and delivered fresh reports, settings became ready, and a deliberate R1 press entered ACTIVE. Motion reached-20.02deg for a-20deg target and+20.00deg for a+20deg target. Moving samples show tracking lag up to about1.2deg at the selected low speed; these sparse samples do not measure peak error. R1 release was followed by disabled confirmation, configuration recovery and READY with R1 released. No TX/readback failure was logged during this run. Android-profile fallback did not prevent fresh gamepad input. This establishes unloaded motion and the observed release/disable sequence, not combined controller/CAN-loss timing, loaded behavior or physical torque-removal timing.

## v0.7: faster unloaded bench test

User confirmed the motor shaft is still unloaded. Maximum target rate and configured motor speed limit increase to1.0rad/s (57.3deg/s), with host target-rate acceleration5.0rad/s^2. Travel stays+/-20deg relative to each deliberate arm; current stays1A and timeout20000counts. All freshness, release/press arming, readback verification, stop and recovery gates remain. From center, the target reaches either boundary in approximately0.45seconds at full stick, including the ramp; this does not predict actual motor arrival or stopping time. Neutral ramps target rate to zero, which can add travel; releasing R1 requests disable immediately. These relative bench limits must not be used with the linkage attached.

Version0.6 movement and R1-release disable are hardware evidenced above. Version0.7 speed, tracking and combined link-loss behavior remain hardware validation tasks. Host checks cover faster ramp/both limits and existing failures; ESP32 compilation passed. No full-power, continuous-rotation, jump or linkage control is introduced.

## v0.8: 80-degree unloaded sweep

After the user reported v0.7 seemed good and requested the full80deg, the bench interval becomes0..+80deg relative to each arming position. Right stick-X direction (positive axis) increases the target; left returns toward0. Negative targets are clamped at0. Encoder-positive direction is not yet verified as physical CCW from the linkage's chosen viewing side. This is an80deg total range, not+/-80deg. The initial arming position is the lower endpoint; releasing/rearming captures a new relative origin. No permanent zero or locked-start calibration is set.

Speed remains1rad/s, current1A, host acceleration5rad/s^2, watchdog20000counts, freshness200ms and existing deliberate arming/stops. Full-stick target sweep takes about1.5seconds from rest; actual arrival depends on tracking. Measured travel monitoring now applies separately to both endpoints with the existing0.035rad guard margin. Simulation covers attempted negative travel at startup, both80deg endpoints, rate ramps and prior recovery/failure paths. v0.8 hardware validation is pending. Use only the disconnected/unloaded shaft; this is not the installed leg controller.

## v0.9: reverse physical extension direction

At the user's direction, extension now decreases the encoder position (EXTEND_SIGN=-1). Controls and displayed logical travel remain right=extend toward80deg, left=retract toward0deg. Motor targets occupy origin-80deg through origin, and measured endpoint monitoring uses the same direction mapping. Target rate is expressed in logical extension coordinates; the displayed positive travel does not imply increasing encoder position or independently establish physical CCW. Speed/current/watchdog and arming behavior are unchanged. The reference still resets on every arm; this remains unloaded bench firmware. Regression simulation explicitly checks negative encoder travel to the80deg endpoint, return to origin, lower-bound rejection and previous faults/recovery. Hardware direction confirmation is pending.

## v0.10: fixed manual reference; held R1 retained

The user cancelled the proposed R1 toggle. This release retains held enable and adds the once-per-startup manual reference, fixed limits, settings checks and reference-invalid lockout described above. Per-arm zero capture has been removed.

## v0.11: controller cancellation must not masquerade as CAN failure

The user reported REF INVALID after switching off the controller. A reproducible v0.10 race explains one possible cause: Bluetooth loss inside an outstanding position read or target readback cancels that operation; callers then treated the false return as transport failure and invalidated zero even when STOP was confirmed. No complete hardware log of the failure was supplied, so this is a matched/reproduced software defect, not proof of the only hardware cause.

Operations now distinguish input cancellation from actual transport/readback/state failure. Position reads, target verification, settings checks and arming carry that reason to the disarm handler before STOP transactions overwrite it. Only input cancellation with no fault/reset evidence and a confirmed STOP preserves reference trust. Timeouts, rejected reads, mismatching/nonfinite values, TX errors and unconfirmed STOP remain invalidating. Interrupted CAN operations print Input cancelled read or input cancelled transaction instead of claiming feedback loss. Reference capture, fixed limits and held R1 behavior are unchanged.

Regression simulation reproduces controller power-off during position0x7019, target0x7016 and current-limit0x7018 reads, plus enable-state confirmation. Each retains the identical origin, stops, refuses automatic re-arm, and permits a fresh release/press after return. A cancelled operation followed by unconfirmed STOP still invalidates. Full host checks and ESP32 compilation pass; hardware confirmation is pending.
